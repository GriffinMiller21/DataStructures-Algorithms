# Title: Electric Car Grid / Dijkstra Algorithmn
# Date: 29/Mar/2024
# Group: 7
# Group Members: Leigh M., Sam L., Azfer A., Griffin M.

# Imports
import csv
import heapq

# Class for graph
class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}
    
    # Adding nodes
    def add_node(self, value):
        self.nodes.add(value)
        if value not in self.edges:
            self.edges[value] = {}
    # Adding edges
    def add_edge(self, from_node, to_node, distance):
        self.add_node(from_node)
        self.add_node(to_node)
        self.edges[from_node][to_node] = distance
        self.edges[to_node][from_node] = distance  
    
    # Algorithm for Dijkstra (finding shortnest path)
    def dijkstra(self, start):
        distances = {node: float('inf') for node in self.nodes}
        distances[start] = 0
        visited = set()
        queue = [(0, start)]
        
        while queue:
            current_distance, current_node = heapq.heappop(queue)
            if current_node in visited:
                continue
            visited.add(current_node)
            
            for neighbor, weight in self.edges[current_node].items():
                distance = current_distance + int(weight)
                if distance < distances[neighbor]:
                    distances[neighbor] = distance
                    heapq.heappush(queue, (distance, neighbor))
        
        return distances

# Loading data from Nodes_and_Edges.csv
def load_network_from_csv(file_path):
    graph = Graph()
    with open(file_path, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            (from_node, to_node, distance) = row
            graph.add_edge(from_node, to_node, distance)
    return graph

def recommend_route(graph, start_node, charging_stations):
    shortest_paths = {}
    for station in charging_stations:
        shortest_paths[station] = graph.dijkstra(start_node)[station]
    recommended_station = min(shortest_paths, key=shortest_paths.get)
    return recommended_station, shortest_paths[recommended_station]

# Output for assignment
def main():
    file_path = 'Nodes_and_Edges.csv'
    graph = load_network_from_csv(file_path)

    # User entry for starting node
    ui = False
    
    # Very dumb way for user verification but I'm exhuasted at this point
    while ui == False:
        starting_node = input("Please enter a starting position between 'A' and 'V': ")
        if starting_node == 'A' or starting_node == 'B' or starting_node == 'C' or starting_node == 'D' or starting_node == 'E' or starting_node == 'F' or starting_node == 'G' or starting_node == 'H' or starting_node == 'I' or starting_node == 'J' or starting_node == 'K' or starting_node == 'L' or starting_node == 'M' or starting_node == 'N' or starting_node == 'O' or starting_node == 'P' or starting_node == 'Q' or starting_node == 'R' or starting_node == 'S' or starting_node == 'T' or starting_node == 'U' or starting_node == 'V' or starting_node == 'W':
            ui=True
        else:
            print("Please enter a capital letter from A-V")

    # Charging stations
    charging_stations = ['H', 'K', 'Q', 'T']
    
    # Assigning shortest paths
    shortest_paths = {}
    for station in charging_stations:
        shortest_paths[station] = graph.dijkstra(starting_node)[station]
    
    # Printing out shortest paths
    print("Shortest paths from node {} to charging stations:".format(starting_node))
    for station, distance in shortest_paths.items():
        print("To {}: {}".format(station, distance))

    # Find the recommended route
    recommended_station, shortest_distance = recommend_route(graph, starting_node, charging_stations)

    # Printing out recommended route
    print(f"The recommended charging station from node {starting_node} is {recommended_station} "
          f"with a shortest distance of {shortest_distance} units.")

if __name__ == "__main__":
    main()
