# Title: Weight Graph Visual
# Date: 29/Mar/2024
# Group: 7
# Group Members: Leigh M., Sam L., Azfer A., Griffin M.

#pip install matplotlib/pip install pyvis incase code doesn't work

# Import
import matplotlib.pyplot as plt
import networkx as nx
from networkx import center

# Creating Grpah 
G = nx.Graph()

# Inputing data into graph
G.add_edge("A", "B", weight=6)
G.add_edge("A", "F", weight=5)
G.add_edge("B", "A", weight=6)
G.add_edge("B", "C", weight=5)
G.add_edge("B", "G", weight=6)
G.add_edge("C", "B", weight=5)
G.add_edge("C", "D", weight=7)
G.add_edge("C", "H", weight=5)
G.add_edge("D", "C", weight=7)
G.add_edge("D", "E", weight=7)
G.add_edge("D", "I", weight=8)
G.add_edge("E", "D", weight=7)
G.add_edge("E", "N", weight=15)
G.add_edge("F", "A", weight=5)
G.add_edge("F", "G", weight=8)
G.add_edge("F", "J", weight=7)
G.add_edge("G", "F", weight=8)
G.add_edge("G", "H", weight=9)
G.add_edge("G", "K", weight=8)
G.add_edge("H", "C", weight=5)
G.add_edge("H", "G", weight=9)
G.add_edge("H", "I", weight=12)
G.add_edge("I", "D", weight=8)
G.add_edge("I", "E", weight=6)
G.add_edge("I", "H", weight=12)
G.add_edge("I", "M", weight=1)
G.add_edge("J", "F", weight=7)
G.add_edge("J", "K", weight=5)
G.add_edge("J", "O", weight=7)
G.add_edge("K", "G", weight=8)
G.add_edge("K", "J", weight=5)
G.add_edge("K", "L", weight=7)
G.add_edge("L", "K", weight=7)
G.add_edge("L", "M", weight=7)
G.add_edge("L", "P", weight=7)
G.add_edge("M", "I", weight=10)
G.add_edge("M", "L", weight=7)
G.add_edge("M", "N", weight=9)
G.add_edge("N", "E", weight=15)
G.add_edge("N", "M", weight=9)
G.add_edge("N", "R", weight=7)
G.add_edge("O", "J", weight=7)
G.add_edge("O", "P", weight=13)
G.add_edge("O", "S", weight=9)
G.add_edge("P", "L", weight=7)
G.add_edge("P", "O", weight=13)
G.add_edge("P", "Q", weight=8)
G.add_edge("P", "U", weight=11)
G.add_edge("Q", "P", weight=8)
G.add_edge("Q", "R", weight=9)
G.add_edge("R", "N", weight=7)
G.add_edge("R", "Q", weight=9)
G.add_edge("R", "W", weight=1)
G.add_edge("S", "O", weight=9)
G.add_edge("S", "T", weight=9)
G.add_edge("T", "S", weight=9)
G.add_edge("T", "U", weight=8)
G.add_edge("U", "P", weight=11)
G.add_edge("U", "T", weight=8)
G.add_edge("U", "V", weight=8)
G.add_edge("V", "U", weight=8)
G.add_edge("V", "W", weight=5)
G.add_edge("W", "R", weight=1)
G.add_edge("W", "V", weight=5)

# Positions for all nodes
pos = nx.spring_layout(G, seed=1) 

# Nodes
nx.draw_networkx_nodes(G, pos, node_size=700)

# Edges
nx.draw_networkx_edges(G, pos, width=5)

# Node labels
nx.draw_networkx_labels(G, pos, font_size=20, font_family="sans-serif")

# Edge weight labels
edge_labels = nx.get_edge_attributes(G, "weight")
nx.draw_networkx_edge_labels(G, pos, edge_labels)

# Printing Graph
ax = plt.gca()
ax.margins(0.08)
plt.axis("off")
plt.tight_layout()
plt.show()